const Discord = require('discord.js');//
const client = new Discord.Client();//
const ayarlar = require('./ayarlar.json');//
const chalk = require('chalk');//
const moment = require('moment');//
var Jimp = require('jimp');//
const fs = require('fs');//
const db = require('quick.db');//
const express = require('express');//
require('./util/eventLoader.js')(client);//
const path = require('path');//
const snekfetch = require('snekfetch');//
//

var prefix = ayarlar.prefix;//
//
const log = message => {//
    console.log(`${message}`);//
};

client.commands = new Discord.Collection();//
client.aliases = new Discord.Collection();//
fs.readdir('./komutlar/', (err, files) => {//
    if (err) console.error(err);//
    log(`${files.length} komut yüklenecek.`);//
    files.forEach(f => {//
        let props = require(`./komutlar/${f}`);//
        log(`Yüklenen komut: ${props.help.name}.`);//
        client.commands.set(props.help.name, props);//
        props.conf.aliases.forEach(alias => {//
            client.aliases.set(alias, props.help.name);//
        });
    });
});




client.reload = command => {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(`./komutlar/${command}`)];
            let cmd = require(`./komutlar/${command}`);
            client.commands.delete(command);
            client.aliases.forEach((cmd, alias) => {
                if (cmd === command) client.aliases.delete(alias);
            });
            client.commands.set(command, cmd);
            cmd.conf.aliases.forEach(alias => {
                client.aliases.set(alias, cmd.help.name);
            });
            resolve();
        } catch (e) {
            reject(e);
        }
    });
};

client.load = command => {
    return new Promise((resolve, reject) => {
        try {
            let cmd = require(`./komutlar/${command}`);
            client.commands.set(command, cmd);
            cmd.conf.aliases.forEach(alias => {
                client.aliases.set(alias, cmd.help.name);
            });
            resolve();
        } catch (e) {
            reject(e);
        }
    });
};



client.unload = command => {
    return new Promise((resolve, reject) => {
        try {
            delete require.cache[require.resolve(`./komutlar/${command}`)];
            let cmd = require(`./komutlar/${command}`);
            client.commands.delete(command);
            client.aliases.forEach((cmd, alias) => {
                if (cmd === command) client.aliases.delete(alias);
            });
            resolve();
        } catch (e) {
            reject(e);
        }
    });
};

client.elevation = message => {
    if (!message.guild) {
        return;
    }

    let permlvl = 0;
    if (message.member.hasPermission("BAN_MEMBERS")) permlvl = 2;
    if (message.member.hasPermission("ADMINISTRATOR")) permlvl = 3;
    if (message.author.id === ayarlar.sahip) permlvl = 4;
    return permlvl;
};

var regToken = /[\w\d]{24}\.[\w\d]{6}\.[\w\d-_]{27}/g;
// client.on('debug', e => {
//   console.log(chalk.bgBlue.green(e.replace(regToken, 'that was redacted')));
// });
client.on('warn', e => {
    console.log(chalk.bgYellow(e.replace(regToken, 'that was redacted')));
});
client.on('error', e => {
    console.log(chalk.bgRed(e.replace(regToken, 'that was redacted')));
});




//---------------------------------- DM DEN HG -----------------------------------\\

client.on("guildMemberAdd", member =>{
    const hg = new Discord.MessageEmbed()
    .setColor('RANDOM')
    .setTitle(member.guild.name + 'Sunucusuna Hoşgeldin!')
    .setDescription(`Sunucumuza Hoşgeldin. \nEğer Klanımıza Katılmak İstiyorsanız <@&809886563814473781> Yetkilileriyle İletişime Geçebilrisiniz.`)
    .setFooter('Hoşgeldin')
    .setTimestamp()
    member.send(hg)
})

//---------------------------------- DM DEN HG -----------------------------------\\


//----------------------------- BOT KANALA YAZIYOR ------------------------------------\\ 

client.on('ready', ()=>{
client.channels.cache.get('811353281203798106').startTyping()
})

//----------------------------- BOT KANALA YAZIYOR ------------------------------------\\ 


//------------------------------ BOT SESLİ KANAL SOKMA ----------------------------------\\

client.on("ready", () => {
  client.channels.cache.get("809886564229840994").join();
})

//------------------------------ BOT SESLİ KANAL SOKMA ----------------------------------\\


//------------------------------ BOT YAYINDA OYNUYOR ------------------------------------\\

client.on("ready", async () => {
   log("Durum başarıyla ayarlandı")
      client.user.setActivity("🤔 -erkek | -kadın |", 
        { url: 'https://twitch.tv/.',
        type: 'STREAMING' }); 
})

//------------------------------ BOT YAYINDA OYNUYOR ------------------------------------\\



//------------------------HOŞGELDİN-EMBEDLİ-----------------------\\     STG

client.on("guildMemberAdd", member => {
    require("moment-duration-format")
      var üyesayısı = member.guild.members.cache.size.toString().replace(/ /g, "    ")
      var üs = üyesayısı.match(/([0-9])/g)
      üyesayısı = üyesayısı.replace(/([a-zA-Z])/g, "bilinmiyor").toLowerCase()
      if(üs) {
        üyesayısı = üyesayısı.replace(/([0-9])/g, d => {
          return {
          '0': `<a:0_:809923796579385384>`,
            '1': `<a:1_:809923803605237820>`,
            '2': `<a:2_:809923814392856577>`,
            '3': `<a:3_:809923830134210560>`,
            '4': `<a:4_:809923848085700650>`,
            '5': `<a:5_:809923848908046396>`,
            '6': `<a:6_:809923861147549767>`,
            '7': `<a:7_:809923881547989004>`,
            '8': `<a:8_:809923892230750218>`,
            '9': `<a:9_:809923895322083409>`}[d];})}
      const kanal = member.guild.channels.cache.find(r => r.id === "809886563814473788");//mesaj atılcak kanal id
      let register = '809886563814473781'
    let user = client.users.cache.get(member.id);
    require("moment-duration-format");
      const kurulus = new Date().getTime() - user.createdAt.getTime();  
     const gecen = moment.duration(kurulus).format(` YY **[Yıl,]** DD **[Gün,]** HH **[Saat,]** mm **[Dakika,]** ss **[Saniye]**`) 
    var kontrol;
  if (kurulus < 1296000000) kontrol = 'Hesap Durumu: <a:tehlikeli:801043752310669343> Güvenilir Değil. <a:tehlikeli:801043752310669343>'
  if (kurulus > 1296000000) kontrol = 'Hesap Durumu: <a:gvenli:801042113709342731> Güvenilir Gözüküyor. <a:gvenli:801042113709342731>'
    moment.locale("tr");
  const embed = new Discord.MessageEmbed()
  .setAuthor(member.guild.name, member.guild.iconURL({dynamic:true}))
  .setDescription(`
  <a:giris:801044033161003009> ┊ <@`+member.id+`> **Sunucumuza Katıldı !** 
  
  <a:kiristal:801043897345114182> ┊ **Kayıt edilmek için teyit odasında <@&${register}> yetkililerine teyit vermen yeterli ! **
  
  <a:robot:801043963959967744> ┊ **Seninle birlikte **{ `+üyesayısı+` }** kişiye ulaştık !**
  
  <a:kitap:801043884653281280> ┊ **Sunucumuzun kurallarına uymayı unutma, kurallarımızı okumanı tavsiye ederiz.**

  <a:dny:801042032683384843> ┊ **Sunucumuzun tagını (\` ✧ \`) alarak bizlere destek olabilirsin**

  <a:elmas:801042046532976771> ┊ **İçeride keyifli vakitler geçirmeni dileriz.**
`)
  .setImage(`https://i.ibb.co/qkhQ2wr/Peding-Hosgeldin.gif`)
  kanal.send(embed)
  kanal.send(`<@&${register}>`)
});
//------------------------HOŞGELDİN-EMBEDLİ-----------------------\\     STG

//------------------------ŞÜPHELİ-HESAP-----------------------\\     STG

client.on("guildMemberAdd", member => {
    var moment = require("moment")
    require("moment-duration-format")
    moment.locale("tr")
     var {Permissions} = require('discord.js');
     var x = moment(member.user.createdAt).add(7, 'days').fromNow()
     var user = member.user
     x = x.replace("birkaç saniye önce", " ")
     if(!x.includes("önce") || x.includes("sonra") ||x == " ") {
    const kytsz = member.guild.roles.cache.find(r => r.id === "809886563797303300") 
     var rol = member.guild.roles.cache.get("809886563797303302") // ŞÜPHELİ HESAP ROLÜNÜN İDSİNİ GİRİN
     var kayıtsız = member.guild.roles.cache.get(kytsz) // UNREGİSTER ROLÜNÜN İDSİNİ GİRİN
     member.roles.add(rol)
     member.roles.remove(kytsz)

  member.user.send('Selam Dostum Ne Yazık ki Sana Kötü Bir Haberim Var Hesabın 1 Hafta Gibi Kısa Bir Sürede Açıldığı İçin Fake Hesap Katagorisine Giriyorsun Lütfen Bir Yetkiliyle İletişime Geç Onlar Sana Yardımcı Olucaktır.')
  setTimeout(() => {
  
  }, 1000)
  
  
     }
          else {
  
          }
      });

//------------------------ŞÜPHELİ-HESAP-----------------------\\     STG


//-----------------------TAG-ROL----------------------\\     STG

client.on("userUpdate", async (stg, yeni) => {
  var sunucu = client.guilds.cache.get('809886563797303296'); // Buraya Sunucu ID
  var uye = sunucu.members.cache.get(yeni.id);
  var ekipTag = "✧"; // Buraya Ekip Tag
  var ekipRolü = "809886563806609512"; // Buraya Ekip Rolünün ID
  var logKanali = "809886564033232907"; // Loglanacağı Kanalın ID

  if (!sunucu.members.cache.has(yeni.id) || yeni.bot || stg.username === yeni.username) return;
  
  if ((yeni.username).includes(ekipTag) && !uye.roles.cache.has(ekipRolü)) {
    try {
      await uye.roles.add(ekipRolü);
      await uye.send(`Tagımızı aldığın için teşekkürler! Aramıza hoş geldin.`);
      await client.channels.cache.get(logKanali).send(new Discord.MessageEmbed().setColor('GREEN').setDescription(`${yeni} adlı üye tagımızı alarak aramıza katıldı!`));
    } catch (err) { console.error(err) };
  };
  
  if (!(yeni.username).includes(ekipTag) && uye.roles.cache.has(ekipRolü)) {
    try {
      await uye.roles.remove(uye.roles.cache.filter(rol => rol.position >= sunucu.roles.cache.get(ekipRolü).position));
      await uye.send(`Tagımızı bıraktığın için ekip rolü ve yetkili rollerin alındı! Tagımızı tekrar alıp aramıza katılmak istersen;\nTagımız: **${ekipTag}**`);
      await client.channels.cache.get(logKanali).send(new Discord.MessageEmbed().setColor('RED').setDescription(`${yeni} adlı üye tagımızı bırakarak aramızdan ayrıldı!`));
    } catch(err) { console.error(err) };
  };
});

//----------------------TAG-KONTROL----------------------\\     STG    

client.on("guildMemberAdd", member => {
  let sunucuid = "809886563797303296"; //Buraya sunucunuzun IDsini yazın
  let tag = "✧"; //Buraya tagınızı yazın
  let rol = "809886563806609512"; //Buraya tag alındığı zaman verilecek rolün IDsini yazın
  let channel = client.guilds.cache.get(sunucuid).channels.cache.find(x => x.name == 'mod-log'); //tagrol-log yerine kendi log kanalınızın ismini yazabilirsiniz
if(member.user.username.includes(tag)){
member.roles.add(rol)
  const tagalma = new Discord.MessageEmbed()
      .setColor("GREEN")
      .setDescription(`<@${member.id}> adlı kişi sunucumuza taglı şekilde katıldı, o doğuştan beri bizden !`)
      .setTimestamp()
     client.channels.cache.get('mod-log').send(tagalma)
}
})

//-----------------------TAG-KONTROL----------------------\\     STG    

 client.login(process.env.token)