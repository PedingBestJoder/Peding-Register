const { MessageEmbed } = require("discord.js")
module.exports.run = async (client, message, users, args) => {

    let yardım = new MessageEmbed()
    .setColor('AQUA')
    .setTitle(`${client.user.username} - Komutlar    <a:3_:809923830134210560><a:1_:809923803605237820>`)
    .setDescription(`
    **\`Register Yardım\`**


    <a:alev_:801042026195714051> \`-erkek/kız <isim> <yas>\`: **Belirtilen Kullanıcıyı Kayıt Edersiniz.**
    <a:yardim:801043996414705664> \`-stat\`: **Etiketlediğin & Kendi Kayıtların Hakkında Bilgi Verir.**
    <a:twich_money:801043938952872016> \`-topteyit\`: **Toplam Teyit Sıralamasını Gösterir.**
    <a:elmas:801042046532976771> \`-kayıtsız\`: **Etiketlediğin Kullanıcıyı Kayıtsıza Atar.**
    <a:yildiz:801044013128876042> \`-kayıt-sıfırla\`: **Kayıt Stats'ları Sıfırlanır.**
    <a:kiristal:801043897345114182> \`-isimler @Üye\`: **Kullanıcının İsimlerini Gösterir.**`)
  .setThumbnail(message.author.avatarURL({dynamic: true}))
  .setImage("https://i.ibb.co/qkhQ2wr/Peding-Hosgeldin.gif")
  .setFooter("Peding Best Coder")
  message.channel.send(yardım)
    
     
    
  };


exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['yardım', 'help'],
  permLevel: 0,
}

exports.help = {
      name: "yardım"
  
}
