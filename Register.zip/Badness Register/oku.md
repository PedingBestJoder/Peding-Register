🔥 **`STRIGA CODE TARAFINDAN YAPILMIŞTIR`** 🔥

✨ **`YOUTUBE KANALIMIN ADRESI`** ✨
`https://www.youtube.com/channel/UC2yLMwMa0vyrBw_Tzhe0U-g?view_as`

🎋 **`DISCROD KOD SUNUCUMUZUN ADRESI`** 🎋



`striganın linki: https://discord.gg/T2YZUkm3HQ`




`sınırsız link: discord.gg/striga`